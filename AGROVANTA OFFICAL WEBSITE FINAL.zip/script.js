/* AGROVANTA website settings: replace these sample values before publishing. */
const AGROVANTA_CONFIG = {
  whatsappNumber: "919725424663", // India number, country code included.
  businessEmail: "agrovanta.exports@gmail.com" // Enquiry email.
};

const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuToggle?.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
  menuToggle.textContent = isOpen ? '×' : '☰';
});
nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle?.setAttribute('aria-expanded', 'false');
  if (menuToggle) { menuToggle.textContent = '☰'; menuToggle.setAttribute('aria-label', 'Open navigation'); }
}));
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('enquiry-form');
form?.addEventListener('submit', event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  const message = [
    'Hello AGROVANTA, I would like to enquire about your products.',
    '', `Name: ${data.name}`, `Company: ${data.company || 'Not provided'}`,
    `Email: ${data.email}`, `Country / Market: ${data.country}`,
    `Product: ${data.product}`, `Estimated quantity: ${data.quantity || 'To be discussed'}`,
    `Requirement: ${data.message || 'Please share product details and quotation.'}`
  ].join('\n');
  const status = document.getElementById('form-status');
  if (!AGROVANTA_CONFIG.whatsappNumber) {
    status.textContent = 'Almost ready! Please replace the sample WhatsApp number in script.js, then submit again. Your enquiry details are ready to be sent.';
    const mailto = `mailto:${AGROVANTA_CONFIG.businessEmail}?subject=${encodeURIComponent('AGROVANTA product enquiry: ' + data.product)}&body=${encodeURIComponent(message)}`;
    if (AGROVANTA_CONFIG.businessEmail) window.location.href = mailto;
    return;
  }
  status.textContent = 'Opening WhatsApp with your enquiry…';
  window.open(`https://wa.me/${AGROVANTA_CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer');
});



const requestedProduct = new URLSearchParams(window.location.search).get('product'); if(requestedProduct && form){ const productMap = {"cumin-seeds":"Cumin Seeds (Jeera)","moringa-powder":"Moringa Powder","red-chilli-powder":"Red Chilli Powder (Lal Mirch)","turmeric-powder":"Turmeric Powder (Haldi)","black-pepper":"Black Pepper (Kali Mirch)","green-cardamom":"Green Cardamom (Elaichi)","mustard-seed-oil":"Mustard Seed Oil","amla-powder":"Amla Powder","castor-oil":"Castor Oil"}; const select=form.querySelector('[name=product]'); if(select && productMap[requestedProduct]) select.value=productMap[requestedProduct]; }

// Click a product card or its photo to open its detail panel.
const productDetails = [
 {name:"Cumin Seeds (Jeera)",category:"WHOLE SPICE",description:"Distinctive aroma and warm, earthy character for food and spice applications.",image:"assets/cumin-seeds.png",url:"/products/cumin-seeds/"},
 {name:"Moringa Powder",category:"BOTANICAL",description:"Finely milled moringa leaf powder for ingredient and food-product markets.",image:"assets/moringa-powder.png",url:"/products/moringa-powder/"},
 {name:"Red Chilli Powder (Lal Mirch)",category:"SPICE POWDER",description:"Vibrant colour and characteristic heat for a wide range of food products.",image:"assets/red-chilli-powder.png",url:"/products/red-chilli-powder/"},
 {name:"Turmeric Powder (Haldi)",category:"SPICE POWDER",description:"Golden-yellow turmeric powder for culinary, seasoning and ingredient uses.",image:"assets/turmeric-powder.png",url:"/products/turmeric-powder/"},
 {name:"Black Pepper (Kali Mirch)",category:"WHOLE SPICE",description:"A bold, pungent spice offered for seasoning, processing and culinary markets.",image:"assets/black-pepper.png",url:"/products/black-pepper/"},
 {name:"Green Cardamom (Elaichi)",category:"WHOLE SPICE",description:"Fragrant green pods suited to culinary, beverage and spice applications.",image:"assets/green-cardamom.png",url:"/products/green-cardamom/"},
 {name:"Mustard Seed Oil",category:"VEGETABLE OIL",description:"Golden oil derived from mustard seeds for food and suitable ingredient applications.",image:"assets/mustard-oil.png",url:"/products/mustard-seed-oil/"},
 {name:"Amla Powder",category:"BOTANICAL POWDER",description:"Ground Indian gooseberry ingredient for food and suitable ingredient formulations.",image:"assets/amla-powder.png",url:"/products/amla-powder/"},
 {name:"Castor Oil",category:"VEGETABLE OIL",description:"Versatile vegetable oil for industrial and suitable ingredient applications.",image:"assets/castor-oil.png",url:"/products/castor-oil/"}
];
const productModal = document.getElementById('product-modal');
const closeProductModal = () => { productModal?.classList.remove('open'); productModal?.setAttribute('aria-hidden','true'); document.body.style.overflow=''; };
document.querySelectorAll('.product-card').forEach((card,index) => {
 const openDetails = event => { if (event.target.closest('.circle-arrow')) return; const item=productDetails[index]; if(!item||!productModal)return; const cardImg=card.querySelector('.product-image img'); const image=document.getElementById('modal-image'); image.src=item.image || cardImg?.src || ''; image.alt=item.name; document.getElementById('modal-title').textContent=item.name; document.getElementById('modal-category').textContent=item.category; document.getElementById('modal-description').textContent=item.description; const enquire=document.getElementById('modal-enquire'); enquire.href='#contact'; enquire.onclick=()=>{closeProductModal();}; const fullDetails=document.getElementById('modal-full-details'); if(fullDetails) fullDetails.href=item.url; productModal.classList.add('open'); productModal.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden'; };
 card.addEventListener('click',openDetails); card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();openDetails(event);}});
});
productModal?.querySelectorAll('[data-close-modal]').forEach(el=>el.addEventListener('click',closeProductModal));
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeProductModal();});
